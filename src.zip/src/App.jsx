import React, { useContext } from "react";
import "./App.css";
import va from "./assets/girl.png";
import { CiMicrophoneOn } from "react-icons/ci";
import { datacontext } from "./context/UserContext";
import speakimg from "./assets/voice wave.gif"

const App = () => {
  let {recognition,speaking,setSpeaking,prompt} = useContext(datacontext);
  return (
    <div className="main">
      <img src={va} alt="" id="girl" />
      <span>I'm Ayush, Your Advanced Virtual Assistant</span>
      {!speaking?<button onClick={()=>{
        setSpeaking(true)
         recognition.start()
      }}>
        Click here <CiMicrophoneOn />
      </button> 
      :
      <div className="response">
        <img src={speakimg} alt="" id="speak"/>
        <p>{prompt} </p>
      </div>
      }
      
    </div>
  );
};

export default App;
