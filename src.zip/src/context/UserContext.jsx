import React, { createContext, useState } from "react";
import run from "../gemini";

export const datacontext = createContext();

const UserContext = ({ children }) => {
  let [speaking, setSpeaking] = useState(false);
  let [prompt, setPrompt] = useState("listening...");

  function speak(text) {
    let text_speak = new SpeechSynthesisUtterance(text);
    text_speak.volume = 1;
    text_speak.rate = 1;
    text_speak.pitch = 1;
    text_speak.lang = "hi-GB";
    window.speechSynthesis.speak(text_speak);
  }
  async function aiResponse(prompt) {
    try {
      let text = await run(prompt);
      setPrompt(text)
      speak(text);
    } catch (error) {
      console.error(error);
      speak("server busy now");
    }
  }
  let SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  let recognition = new SpeechRecognition();
  recognition.onresult = (e) => {
    recognition.stop();

    let transcript = e.results[e.resultIndex][0].transcript;
    setPrompt(transcript);
    aiResponse(transcript);
  };

  let value = {
    recognition,
    speaking,
    setSpeaking,
    setPrompt,
    setPrompt,
  };
  return (
    <>
      <datacontext.Provider value={value}>{children}</datacontext.Provider>
    </>
  );
};

export default UserContext;
